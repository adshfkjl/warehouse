using Microsoft.AspNetCore.Mvc;
using PLCManagement.API.Interfaces;
using PLCManagement.API.Models.Dtos;
using PLCManagement.API.Models;

namespace PLCManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TrayPreUploadController : ControllerBase
    {
        private readonly ITrayPreUploadService _trayPreUploadService;
        private readonly ILogger<TrayPreUploadController> _logger;

        // ʹ�������캯���򻯴���
        public TrayPreUploadController(
            ITrayPreUploadService trayPreUploadService,
            ILogger<TrayPreUploadController> logger)
        {
            _trayPreUploadService = trayPreUploadService;
            _logger = logger;
        }

        /// <summary>
        /// �Ǽ�Ԥ�ϼܻ���
        /// </summary>
        /// <param name="request">Ԥ�ϼ�����</param>
        /// <returns>�������</returns>
        [HttpPost("register")]
        [ProducesResponseType(typeof(ApiResponse<TrayPreUploadResponse>), 200)]
        [ProducesResponseType(typeof(ApiResponse<string>), 400)]
        [ProducesResponseType(typeof(ApiResponse<string>), 500)]
        public async Task<IActionResult> RegisterPreUploadTray([FromBody] TrayPreUploadRequest request)
        {
            try
            {
                if (request == null)
                {
                    return BadRequest(new ApiResponse<string>
                    {
                        Success = false,
                        Message = "�����������Ϊ��",
                        Data = null
                    });
                }

                // ��֤�����ֶ�
                if (string.IsNullOrWhiteSpace(request.DocumentNo))
                {
                    return BadRequest(new ApiResponse<string>
                    {
                        Success = false,
                        Message = "���ݱ�Ų���Ϊ��",
                        Data = "DocumentNo is required"
                    });
                }

                if (string.IsNullOrWhiteSpace(request.PLCID))
                {
                    return BadRequest(new ApiResponse<string>
                    {
                        Success = false,
                        Message = "PLC��Ų���Ϊ��",
                        Data = "PLCID is required"
                    });
                }

                _logger.LogInformation("���յ�Ԥ�ϼܻ���Ǽ����󣺵��ݱ��={DocumentNo}, PLC={PLCID}, װ�ص�={LoadingPoint}",
                    request.DocumentNo, request.PLCID, request.LoadingPoint);

                var result = await _trayPreUploadService.RegisterPreUploadTrayAsync(request);

                if (result.Success)
                {
                    return Ok(new ApiResponse<TrayPreUploadResponse>
                    {
                        Success = true,
                        Message = "Ԥ�ϼܻ���Ǽǳɹ�",
                        Data = result
                    });
                }
                else
                {
                    return BadRequest(new ApiResponse<TrayPreUploadResponse>
                    {
                        Success = false,
                        Message = result.Message,
                        Data = result
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ԥ�ϼܻ���Ǽ�API�쳣��{Message}", ex.Message);
                return StatusCode(500, new ApiResponse<string>
                {
                    Success = false,
                    Message = "ϵͳ�����쳣",
                    Data = ex.Message
                });
            }
        }

        /// <summary>
        /// ��ѯԤ�ϼܼ�¼
        /// </summary>
        /// <param name="documentNo">���ݱ��</param>
        /// <param name="plcId">PLC���</param>
        /// <returns>Ԥ�ϼܼ�¼�б�</returns>
        [HttpGet("records")]
        [ProducesResponseType(typeof(ApiResponse<List<TrayPreUploadRecordDto>>), 200)]
        [ProducesResponseType(typeof(ApiResponse<string>), 500)]
        public async Task<IActionResult> GetPreUploadRecords(
            [FromQuery] string documentNo = null,
            [FromQuery] string plcId = null)
        {
            try
            {
                _logger.LogInformation("��ѯԤ�ϼܼ�¼��DocumentNo={DocumentNo}, PLCID={PLCID}",
                    documentNo, plcId);

                var records = await _trayPreUploadService.GetPreUploadRecordsAsync(documentNo, plcId);

                return Ok(new ApiResponse<List<TrayPreUploadRecordDto>>
                {
                    Success = true,
                    Message = "��ѯ�ɹ�",
                    Data = records
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "��ѯԤ�ϼܼ�¼API�쳣��{Message}", ex.Message);
                return StatusCode(500, new ApiResponse<string>
                {
                    Success = false,
                    Message = "��ѯ�쳣",
                    Data = ex.Message
                });
            }
        }

        /// <summary>
        /// Ԥ�ϼܻ���Ǽǣ�GET��ʽ�������ڼ򵥵��ã�
        /// </summary>
        [HttpGet("register")]
        public async Task<IActionResult> RegisterPreUploadTrayGet(
            [FromQuery] string documentNo,
            [FromQuery] string plcId,
            [FromQuery] int loadingPoint = 0,
            [FromQuery] string palletCode = null,
            [FromQuery] string remark = null)
        {
            var request = new TrayPreUploadRequest
            {
                DocumentNo = documentNo,
                PLCID = plcId,
                LoadingPoint = loadingPoint,
                PalletCode = palletCode,
                Remark = remark
            };

            // ����POST����
            return await RegisterPreUploadTray(request);
        }
    }
}