using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PLCManagement.API.Interfaces;
using PLCManagement.API.Models.Dtos;
using System.Data;
using System.Text;

namespace PLCManagement.API.Services
{
    public class TrayPreUploadService : ITrayPreUploadService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<TrayPreUploadService> _logger;

        public TrayPreUploadService(
            IConfiguration configuration,
            ILogger<TrayPreUploadService> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<TrayPreUploadResponse> RegisterPreUploadTrayAsync(TrayPreUploadRequest request)
        {
            var response = new TrayPreUploadResponse();
            var connectionString = _configuration.GetConnectionString("StoreHouseConnection");

            try
            {
                _logger.LogInformation("��ʼ�Ǽ�Ԥ�ϼܻ��򣺵��ݱ��={DocumentNo}, PLC={PLCID}, װ�ص�={LoadingPoint}",
                    request.DocumentNo, request.PLCID, request.LoadingPoint);

                // ���ô洢���� SDL_UPLoadTray
                using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                using var command = new SqlCommand("StoreHouse.dbo.[SDL_UPLoadTray]", connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                // ���Ӵ洢���̲���
                command.Parameters.Add(new SqlParameter("@Bil_NO", SqlDbType.VarChar, 50) { Value = request.DocumentNo });
                command.Parameters.Add(new SqlParameter("@PLCID", SqlDbType.VarChar, 50) { Value = request.PLCID });
                command.Parameters.Add(new SqlParameter("@LoadingPoint", SqlDbType.Int) { Value = request.LoadingPoint });

                // �����������
                var resultFlagParam = new SqlParameter("@ResultFlag", SqlDbType.Int) { Direction = ParameterDirection.Output };

                command.Parameters.AddRange(new[]
                {
                    resultFlagParam
                });

                await command.ExecuteNonQueryAsync();

                // ��ȡ�������ֵ
                response.ResultFlag = resultFlagParam.Value != DBNull.Value ? Convert.ToInt32(resultFlagParam.Value) : 0;
                response.Success = response.ResultFlag == 1;

                if (response.Success)
                {
                    response.Message = "Ԥ�ϼܻ���Ǽǳɹ�";
                    _logger.LogInformation("Ԥ�ϼܻ���Ǽǳɹ������ݱ��={DocumentNo}, PLC={PLCID}, װ�ص�={LoadPoint}",
                        request.DocumentNo, request.PLCID, request.LoadingPoint);
                }
                else
                {
                    response.Message = $"Ԥ�ϼܻ���Ǽ�ʧ�ܣ�{response.ErrorMessage}";
                    _logger.LogWarning("Ԥ�ϼܻ���Ǽ�ʧ�ܣ����ݱ��={DocumentNo}, PLC={PLCID}, װ�ص�={LoadPoint}",
                        request.DocumentNo, request.PLCID, request.LoadingPoint);
                }
            }
            catch (SqlException sqlEx)
            {
                _logger.LogError(sqlEx, "���ݿ��쳣�Ǽ�Ԥ�ϼܻ��򣺵��ݱ��={DocumentNo}, PLC={PLCID}",
                    request.DocumentNo, request.PLCID);
                response.Success = false;
                response.Message = $"���ݿ��쳣��{sqlEx.Message}";
                response.ErrorMessage = sqlEx.Message;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�Ǽ�Ԥ�ϼܻ����쳣�����ݱ��={DocumentNo}, PLC={PLCID}",
                    request.DocumentNo, request.PLCID);
                response.Success = false;
                response.Message = $"ϵͳ�쳣��{ex.Message}";
                response.ErrorMessage = ex.Message;
            }

            return response;
        }

        public async Task<List<TrayPreUploadRecordDto>> GetPreUploadRecordsAsync(string documentNo = null, string plcId = null)
        {
            var records = new List<TrayPreUploadRecordDto>();
            var connectionString = _configuration.GetConnectionString("StoreHouseConnection");

            try
            {
                using var connection = new SqlConnection(connectionString);
                await connection.OpenAsync();

                // ������ѯSQL
                var sql = new StringBuilder(@"
                    SELECT TOP 100 
                        Id, DocumentNo, PLCID, LoadingPoint, PalletCode, 
                        Remark, CreateTime, Status
                    FROM PreUploadTray_Log
                    WHERE 1=1
                ");

                // ����ɸѡ����
                var parameters = new List<SqlParameter>();

                if (!string.IsNullOrEmpty(documentNo))
                {
                    sql.Append(" AND DocumentNo LIKE @DocumentNo");
                    parameters.Add(new SqlParameter("@DocumentNo", SqlDbType.VarChar, 50) { Value = $"%{documentNo}%" });
                }

                if (!string.IsNullOrEmpty(plcId))
                {
                    sql.Append(" AND PLCID = @PLCID");
                    parameters.Add(new SqlParameter("@PLCID", SqlDbType.VarChar, 50) { Value = plcId });
                }

                sql.Append(" ORDER BY CreateTime DESC");

                using var command = new SqlCommand(sql.ToString(), connection);
                command.Parameters.AddRange(parameters.ToArray());

                using var reader = await command.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    var record = new TrayPreUploadRecordDto
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        DocumentNo = reader["DocumentNo"].ToString() ?? string.Empty,
                        PLCID = reader["PLCID"].ToString() ?? string.Empty,
                        LoadingPoint = Convert.ToInt32(reader["LoadingPoint"]),
                        PalletCode = reader["PalletCode"].ToString() ?? string.Empty,
                        Remark = reader["Remark"].ToString() ?? string.Empty,
                        CreateTime = Convert.ToDateTime(reader["CreateTime"]),
                        Status = reader["Status"].ToString() ?? string.Empty
                    };
                    records.Add(record);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "��ѯԤ�ϼܼ�¼�쳣��DocumentNo={DocumentNo}, PLCID={PLCID}",
                    documentNo, plcId);
            }

            return records;
        }
    }
}