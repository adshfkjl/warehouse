using PLCManagement.API.Models.Dtos;

namespace PLCManagement.API.Interfaces
{
    /// <summary>
    /// Ԥ�ϼܻ���ǼǷ���ӿ�
    /// </summary>
    public interface ITrayPreUploadService
    {
        /// <summary>
        /// �Ǽ�Ԥ�ϼܻ���
        /// </summary>
        /// <param name="request">Ԥ�ϼ�����</param>
        /// <returns>�������</returns>
        Task<TrayPreUploadResponse> RegisterPreUploadTrayAsync(TrayPreUploadRequest request);

        /// <summary>
        /// ��ѯԤ�ϼܼ�¼
        /// </summary>
        /// <param name="documentNo">���ݱ��</param>
        /// <param name="plcId">PLC���</param>
        /// <returns>Ԥ�ϼܼ�¼�б�</returns>
        Task<List<TrayPreUploadRecordDto>> GetPreUploadRecordsAsync(string documentNo = null, string plcId = null);
    }

    /// <summary>
    /// Ԥ�ϼܼ�¼DTO
    /// </summary>
    public class TrayPreUploadRecordDto
    {
        public int Id { get; set; }
        public string DocumentNo { get; set; } = string.Empty;
        public string PLCID { get; set; } = string.Empty;
        public int LoadingPoint { get; set; }
        public string PalletCode { get; set; } = string.Empty;
        public string Remark { get; set; } = string.Empty;
        public DateTime CreateTime { get; set; }
        public string Status { get; set; } = string.Empty;
    }
}